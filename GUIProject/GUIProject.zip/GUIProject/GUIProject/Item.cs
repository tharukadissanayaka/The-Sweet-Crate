﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Automation;

namespace GUIProject
{
    public class Item
    {
        public int ItemId { get; set; }
        public string Name { get; set; }
        public double ItemPrice { get; set; }
    }
}